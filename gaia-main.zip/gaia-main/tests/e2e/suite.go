package e2e

import (
	"github.com/cosmos/gaia/v23/tests/e2e/tx"
)

type IntegrationTestSuite struct {
	tx.TestingSuite
}
