package gaia

const (
	appName = "GaiaApp"
)
