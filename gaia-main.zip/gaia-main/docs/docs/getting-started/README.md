---
title: Getting Started
order: null
---

This folder contains tutorials related to the `gaia` application.

- [What is Gaia?](./what-is-gaia.md)
- [Installing `gaiad`](./installation.md)
- [Joining Mainnet](./quickstart.md)
