package types

const (
	ModuleName = "metaprotocols"
)
