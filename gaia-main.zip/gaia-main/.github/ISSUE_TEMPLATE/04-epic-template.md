---
name: Epic Template
about: Basic template for epics (used by the team)
title: "[Epic]: "
labels: ['admin: epic', 'status: waiting-triage']
---

## Problem

<!-- Please write a concise 1-3 line problem. -->

## Closing criteria

<!-- Please write a satisfiable criteria for closing this issue. -->


## Problem details

<!-- Please describe the problem in all detail. -->

## Task list

```[tasklist]
### Must have

```

```[tasklist]
### Nice to have

```