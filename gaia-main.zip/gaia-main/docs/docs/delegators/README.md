---
title: Delegators
order: 1
---

This folder contains documentation relevant to delegators of the Cosmos Hub and other `gaia` blockchains.

- [Delegator CLI Guide](./delegator-guide-cli.md)
- [Delegators FAQ](./delegator-faq.md)
- [Delegator Security Notice](./delegator-security.md)
