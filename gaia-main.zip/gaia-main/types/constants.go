package types

const UAtomDenom string = "uatom"
